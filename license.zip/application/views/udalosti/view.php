<div class="container">
    <div class="row"><br></div>
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">Viac o události <a href="<?php echo site_url('Udalosti/'); ?>" class="glyphicon glyphicon-arrow-left pull-right"></a></div>
            <div class="panel-body">
                <div class="form-group">
                    <label>ID Miesta:</label>
                    <p><?php echo !empty($Udalosti['miesta_idmiesta'])?$Udalosti['miesta_idmiesta']:''; ?></p>
                </div>
                <div class="form-group">
                    <label>ID Oslavy:</label>
                    <p><?php echo !empty($Udalosti['rodinne_oslavy_idrodinne_oslavy'])?$Udalosti['rodinne_oslavy_idrodinne_oslavy']:''; ?></p>
                </div>
                <div class="form-group">
                    <label>Dátum:</label>
                    <p><?php echo !empty($Udalosti['datum'])?$Udalosti['datum']:''; ?></p>
                </div>
                <div class="form-group">
                    <label>Počet osôb:</label>
                    <p><?php echo !empty($Udalosti['pocet_osob'])?$Udalosti['pocet_osob']:''; ?></p>
                </div><div class="form-group">
                    <label>Cena:</label>
                    <p><?php echo !empty($Udalosti['cena'])?$Udalosti['cena']:''; ?></p>
                </div><div class="form-group">
                    <label>Možnosti platby:</label>
                    <p><?php echo !empty($Udalosti['moznosti_platby_idmoznosti_platby'])?$Udalosti['moznosti_platby_idmoznosti_platby']:''; ?></p>
                </div>
                <div class="form-group">
                    <label>Zákazník:</label>
                    <p><?php echo !empty($Udalosti['zakaznici_id'])?$Udalosti['zakaznici_id']:''; ?></p>
                </div>
                
                


            </div>
        </div>
    </div>
</div>


<?php
/**
 * Created by PhpStorm.
 * User: pstoj
 * Date: 4.5.2018
 * Time: 13:52
 */