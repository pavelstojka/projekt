<div class="container">
    <div class="row"><br></div>
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">Viac o úlohe <a href="<?php echo site_url('Uloha_zamestnancov/'); ?>" class="glyphicon glyphicon-arrow-left pull-right"></a></div>
            <div class="panel-body">
                <div class="form-group">
                    <label>ID Zamestnanca:</label>
                    <p><?php echo !empty($Uloha_zamestnancov['zamestnanci_idzamestnanci'])?$Uloha_zamestnancov['zamestnanci_idzamestnanci']:''; ?></p>
                </div>
                <div class="form-group">
                    <label>ID Oslavy:</label>
                    <p><?php echo !empty($Uloha_zamestnancov['rodinne_oslavy_idrodinne_oslavy'])?$Uloha_zamestnancov['rodinne_oslavy_idrodinne_oslavy']:''; ?></p>
                </div>
                <div class="form-group">
                    <label>Úloha:</label>
                    <p><?php echo !empty($Uloha_zamestnancov['Uloha'])?$Uloha_zamestnancov['Uloha']:''; ?></p>
                </div>


            </div>
        </div>
    </div>
</div>


<?php
/**
 * Created by PhpStorm.
 * User: pstoj
 * Date: 4.5.2018
 * Time: 13:52
 */